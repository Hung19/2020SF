function updateDB(table, passvalue) {
      //document.getElementById("watering_message").innerHTML = passvalue;
      var xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
          document.getElementById("watering_message").innerHTML = this.responseText;
        }
      };
      xhttp.open("GET", "php/dataupdate.php?table=" + table +"&passvalue=" + passvalue, true);
      xhttp.send();
    }
