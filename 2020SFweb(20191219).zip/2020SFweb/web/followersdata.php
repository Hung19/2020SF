<?php
//setting header to json
header('Content-Type: application/json');

//database
define('DB_HOST', 'chi-node41.websitehostserver.net');
define('DB_USERNAME', 'carltonh_cage20');
define('DB_PASSWORD', '2001919Carlton');
define('DB_NAME', 'carltonh_cage20');

//get connection
$mysqli = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);

if(!$mysqli){
  die("Connection failed: " . $mysqli->error);
}

//query to get data from the table
$query = sprintf("SELECT T, hum, lig, tem FROM sensor");

//execute query
$result = $mysqli->query($query);


//loop through the returned data
$data = array();
foreach ($result as $row) {
  $data[] = $row;
}

//free memory associated with result
$result->close();

//close connection
$mysqli->close();

//now print the data
print json_encode($data);
