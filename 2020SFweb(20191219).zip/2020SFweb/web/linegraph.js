window.onload = function(){
  var updatechart = function(){
    $.ajax({
      url : "http://carltonhung.com/2020SFweb/web/followersdata.php",
      type : "PUT",
      success : function(data){
        console.log(data);

        var id = [];
        var hum = [];
        var lig = [];
        var tem = [];

        for(var i in data) {
          id.push(data[i].T);
          hum.push(data[i].hum);
          lig.push(data[i].lig);
          tem.push(data[i].tem);
        }

        var chartdata = {
          labels: id,
          datasets: [
            {
              label: "humanity",
              fill: false,
              lineTension: 0.1,
              backgroundColor: "rgba(59, 89, 152, 0.75)",
              borderColor: "rgba(59, 89, 152, 1)",
              pointHoverBackgroundColor: "rgba(59, 89, 152, 1)",
              pointHoverBorderColor: "rgba(59, 89, 152, 1)",
              data: hum
            },
            {
              label: "light",
              fill: false,
              lineTension: 0.1,
              backgroundColor: "rgba(29, 202, 255, 0.75)",
              borderColor: "rgba(29, 202, 255, 1)",
              pointHoverBackgroundColor: "rgba(29, 202, 255, 1)",
              pointHoverBorderColor: "rgba(29, 202, 255, 1)",
              data: lig
            },
            {
              label: "temperture",
              fill: false,
              lineTension: 0.1,
              backgroundColor: "rgba(211, 72, 54, 0.75)",
              borderColor: "rgba(211, 72, 54, 1)",
              pointHoverBackgroundColor: "rgba(211, 72, 54, 1)",
              pointHoverBorderColor: "rgba(211, 72, 54, 1)",
              data: tem
            }
          ]
        };

        var ctx = $("#mycanvas");

        var LineGraph = new Chart(ctx, {
          type: 'line',
          data: chartdata
        });
      },
      error : function(data) {

      }
    });
  };
var updateInterval = 5000;
setInterval(function(){updatechart()},updateInterval);
};
