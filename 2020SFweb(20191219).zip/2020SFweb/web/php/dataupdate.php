<?php
$passvalue = $_GET['passvalue'];
echo $passvalue;
$table = $_GET['table'];
echo $table;
$servername = "chi-node41.websitehostserver.net";
$user = "carltonh_cage20";
$password = "2001919Carlton";
$data = "carltonh_cage20";

$con = new mysqli($servername,$user,$password,$data);

$sql = "insert into $table (status) values ('$passvalue')";

if($con->query($sql)===true){
  echo "successfully";
}else {
	echo "data insert error: "."<br/>".$con->error;
	header("refresh:2; $url");
}
$con->close();
?>
