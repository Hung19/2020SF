
<?php
$url = "../Cage Control.html";
$water_m = $_GET["water_m"];
$servername = "localhost";
$user = "root";
$password = "";
$data = "water m";

$con = new mysqli($servername,$user,$password,$data);

$sql = "insert into switch(switch) values ('$water_m')";  //插入数据到数据库语句
if($con->query($sql)===true){
	echo "<script type='text/javascript'>";
	echo "window.location.href='$url'";
	echo "</script>";
}else {
	echo "data insert error: "."<br/>".$con->error;

}
$con->close();
?>
