
<?php
$url = "../Cage Control.html";
$light_m = $_GET["light_m"];
$servername = "localhost";
$user = "root";
$password = "";
$data = "light m";

$con = new mysqli($servername,$user,$password,$data);

$sql = "insert into switch(switch) values ('$light_m')";
if($con->query($sql)===true){
	echo "<script type='text/javascript'>";
	echo "window.location.href='$url'";
	echo "</script>";
}else {
	echo "data insert error: "."<br/>".$con->error;

}
$con->close();
?>
