
<?php
$url = "../Cage Control.html";
$hsetting = $_POST["Hsetting"];
$servername = "localhost";
$user = "root";
$password = "";
$data = "heater setting";

$con = new mysqli($servername,$user,$password,$data);

$sql = "insert into heater(value) values ('$hsetting')";  //插入数据到数据库语句
if($con->query($sql)===true){
	echo "<script type='text/javascript'>";
	echo "window.location.href='$url'";
	echo "</script>";
}else {
	echo "data insert error: "."<br/>".$con->error;
	header("refresh:2; $url");
}

$con->close();
?>
