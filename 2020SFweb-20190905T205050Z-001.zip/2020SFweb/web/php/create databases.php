<?php
$servername = "localhost";
$username = "root";
$password = "";


// Create connection
$conn = new mysqli($servername, $username, $password);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Create database
$sql = "CREATE DATABASE fan_m";
$sql .= "CREATE TABLE switch (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
switch VARCHAR(30) NOT NULL,
)";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . $conn->error;
}
$conn->close();
?>
