<?php
$passvalue = $_GET['passvalue'];
echo $passvalue;
$table = $_GET['table'];
echo $table;
$servername = "localhost";
$user = "root";
$password = "";
$data = "cage20";

$con = new mysqli($servername,$user,$password,$data);

$sql = "insert into $table (status) values ('$passvalue')";

if($con->query($sql)===true){
  echo "successfully";
}else {
	echo "data insert error: "."<br/>".$con->error;
	header("refresh:2; $url");
}
$con->close();
?>
