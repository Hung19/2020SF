
<?php
$url = "../Cage Control.html";
$fsetting = $_POST["Fsetting"];
$servername = "localhost";
$user = "root";
$password = "";
$data = "fan setting";

$con = new mysqli($servername,$user,$password,$data);

$sql = "insert into fan(value) values ('$fsetting')";  //插入数据到数据库语句
if($con->query($sql)===true){
	echo "<script type='text/javascript'>";
	echo "window.location.href='$url'";
	echo "</script>";
}else {
	echo "data insert error: "."<br/>".$con->error;
	header("refresh:2; $url");
}
$con->close();
?>
