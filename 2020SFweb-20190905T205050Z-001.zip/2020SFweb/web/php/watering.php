
<?php
include('deletefile_water.php');
$url = "../Cage Control.html";
$wsetting = $_POST["Wsetting"];
$servername = "localhost";
$user = "root";
$password = "";
$data = "water setting";

$con = new mysqli($servername,$user,$password,$data);

$sql = "insert into watering(value) values ('$wsetting')";  //插入数据到数据库语句
if($con->query($sql)===true){
	echo "<script type='text/javascript'>";
	echo "window.location.href='$url'";
	echo "</script>";
}else {
	echo "data insert error: "."<br/>".$con->error;
	header("refresh:2; $url");
}

$con->close();
?>
